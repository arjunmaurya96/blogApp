import React from 'react'

const UpdateBlog = () => {
  return (
    <div>UpdateBlog</div>
  )
}

export default UpdateBlog